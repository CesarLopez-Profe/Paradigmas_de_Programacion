﻿
namespace F_Transito
{
    partial class f_multas
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_conductores = new System.Windows.Forms.ListBox();
            this.lb_multas = new System.Windows.Forms.ListBox();
            this.b_cargar_cond = new System.Windows.Forms.Button();
            this.b_multar_mayor = new System.Windows.Forms.Button();
            this.b_multar_menor = new System.Windows.Forms.Button();
            this.tb_total_mayores = new System.Windows.Forms.TextBox();
            this.tb_total_menores = new System.Windows.Forms.TextBox();
            this.cbo_may = new System.Windows.Forms.ComboBox();
            this.cbo_men = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lb_conductores
            // 
            this.lb_conductores.FormattingEnabled = true;
            this.lb_conductores.ItemHeight = 20;
            this.lb_conductores.Location = new System.Drawing.Point(117, 95);
            this.lb_conductores.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lb_conductores.Name = "lb_conductores";
            this.lb_conductores.Size = new System.Drawing.Size(342, 304);
            this.lb_conductores.TabIndex = 0;
            // 
            // lb_multas
            // 
            this.lb_multas.FormattingEnabled = true;
            this.lb_multas.ItemHeight = 20;
            this.lb_multas.Location = new System.Drawing.Point(783, 95);
            this.lb_multas.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lb_multas.Name = "lb_multas";
            this.lb_multas.Size = new System.Drawing.Size(412, 304);
            this.lb_multas.TabIndex = 1;
            // 
            // b_cargar_cond
            // 
            this.b_cargar_cond.Location = new System.Drawing.Point(171, 418);
            this.b_cargar_cond.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.b_cargar_cond.Name = "b_cargar_cond";
            this.b_cargar_cond.Size = new System.Drawing.Size(214, 35);
            this.b_cargar_cond.TabIndex = 2;
            this.b_cargar_cond.Text = "Cargar Conductores";
            this.b_cargar_cond.UseVisualStyleBackColor = true;
            this.b_cargar_cond.Click += new System.EventHandler(this.b_cargar_cond_Click);
            // 
            // b_multar_mayor
            // 
            this.b_multar_mayor.Location = new System.Drawing.Point(543, 189);
            this.b_multar_mayor.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.b_multar_mayor.Name = "b_multar_mayor";
            this.b_multar_mayor.Size = new System.Drawing.Size(140, 35);
            this.b_multar_mayor.TabIndex = 3;
            this.b_multar_mayor.Text = "Multar Mayor";
            this.b_multar_mayor.UseVisualStyleBackColor = true;
            this.b_multar_mayor.Click += new System.EventHandler(this.b_multar_mayor_Click);
            // 
            // b_multar_menor
            // 
            this.b_multar_menor.Location = new System.Drawing.Point(543, 380);
            this.b_multar_menor.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.b_multar_menor.Name = "b_multar_menor";
            this.b_multar_menor.Size = new System.Drawing.Size(140, 35);
            this.b_multar_menor.TabIndex = 4;
            this.b_multar_menor.Text = "Multar Menor";
            this.b_multar_menor.UseVisualStyleBackColor = true;
            this.b_multar_menor.Click += new System.EventHandler(this.b_multar_menor_Click);
            // 
            // tb_total_mayores
            // 
            this.tb_total_mayores.Location = new System.Drawing.Point(783, 505);
            this.tb_total_mayores.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_total_mayores.Name = "tb_total_mayores";
            this.tb_total_mayores.ReadOnly = true;
            this.tb_total_mayores.Size = new System.Drawing.Size(184, 26);
            this.tb_total_mayores.TabIndex = 5;
            // 
            // tb_total_menores
            // 
            this.tb_total_menores.Location = new System.Drawing.Point(1010, 505);
            this.tb_total_menores.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_total_menores.Name = "tb_total_menores";
            this.tb_total_menores.ReadOnly = true;
            this.tb_total_menores.Size = new System.Drawing.Size(202, 26);
            this.tb_total_menores.TabIndex = 6;
            // 
            // cbo_may
            // 
            this.cbo_may.FormattingEnabled = true;
            this.cbo_may.Location = new System.Drawing.Point(507, 148);
            this.cbo_may.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbo_may.Name = "cbo_may";
            this.cbo_may.Size = new System.Drawing.Size(241, 28);
            this.cbo_may.TabIndex = 7;
            this.cbo_may.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // cbo_men
            // 
            this.cbo_men.FormattingEnabled = true;
            this.cbo_men.Location = new System.Drawing.Point(492, 338);
            this.cbo_men.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbo_men.Name = "cbo_men";
            this.cbo_men.Size = new System.Drawing.Size(280, 28);
            this.cbo_men.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(534, 95);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Multas Mayores";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(532, 309);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Multas Menores";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(117, 66);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Conductores";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(783, 65);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "Multas";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(783, 434);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "$$$Recaudado";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(788, 475);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 20);
            this.label6.TabIndex = 14;
            this.label6.Text = "Total Mayores";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1010, 475);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 20);
            this.label7.TabIndex = 15;
            this.label7.Text = "Total Menores";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1272, 688);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbo_men);
            this.Controls.Add(this.cbo_may);
            this.Controls.Add(this.tb_total_menores);
            this.Controls.Add(this.tb_total_mayores);
            this.Controls.Add(this.b_multar_menor);
            this.Controls.Add(this.b_multar_mayor);
            this.Controls.Add(this.b_cargar_cond);
            this.Controls.Add(this.lb_multas);
            this.Controls.Add(this.lb_conductores);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lb_conductores;
        private System.Windows.Forms.ListBox lb_multas;
        private System.Windows.Forms.Button b_cargar_cond;
        private System.Windows.Forms.Button b_multar_mayor;
        private System.Windows.Forms.Button b_multar_menor;
        private System.Windows.Forms.TextBox tb_total_mayores;
        private System.Windows.Forms.TextBox tb_total_menores;
        private System.Windows.Forms.ComboBox cbo_may;
        private System.Windows.Forms.ComboBox cbo_men;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}

