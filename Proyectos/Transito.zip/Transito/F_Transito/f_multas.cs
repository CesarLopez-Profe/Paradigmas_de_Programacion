﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using b_Transito.Clases;
using System.IO;

namespace F_Transito
{
    public partial class f_multas : Form
    {
        //Crear organismo de tránsito como atributo de la clase form1
        Transito of_transito = new Transito(1000000);
        List<Conductor> l_cond = new List<Conductor>();

        public f_multas()
        {
            InitializeComponent();

            //llenar los combos de los enum
            cbo_may.DataSource = Enum.GetValues(typeof (Mayor.l_inf_mayores));
            cbo_men.DataSource = Enum.GetValues(typeof(Menor.l_inf_menores));
            Set_recaudos();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void b_cargar_cond_Click(object sender, EventArgs e)
        {
            try
            {

                string[] v_split;
                string linea, ruta;
                StreamReader archivo;
                Conductor.l_ids tipo_doc;
                byte edad = 0;
                int cont_lin = 0;

                ruta = Obtener_ruta();

                if(!String.IsNullOrEmpty(ruta) && !String.IsNullOrWhiteSpace(ruta))
                {
                    archivo = new StreamReader(ruta);
                    linea = archivo.ReadLine();

                    while(linea != null)
                    {
                        cont_lin++;
                        v_split = linea.Split(';');

                        if (Enum.TryParse(v_split[0], out tipo_doc) && Byte.TryParse(v_split[3], out edad))
                            l_cond.Add(new Conductor(tipo_doc, v_split[1], v_split[2], edad));
                        else
                            throw new Exception("El archivo tiene información errónea, revise la línea " + cont_lin);
         
                        linea = archivo.ReadLine();
                    }

                    archivo.Close();

                    lb_conductores.DataSource = l_cond;
                }
            }
            catch (Exception error)
            {
                throw new Exception("Error cargando conductores\n" + error);
            }
            
            
        }

        private String Obtener_ruta()
        {
            try
            {
                OpenFileDialog ventana;

                do
                {
                    ventana = new OpenFileDialog();
                    ventana.Filter = "TXT|*.txt |CSV|*.csv";

                } while (ventana.ShowDialog() != DialogResult.OK);

                return ventana.FileName;

            }
            catch(Exception error)
            {
                throw new Exception ("Error en obtener ruta\n" + error);
            }
        }

        private void b_multar_mayor_Click(object sender, EventArgs e)
        {
            try
            {
                
                
                if (lb_conductores.SelectedIndex == -1)
                    MessageBox.Show("Debe seleccionar un conductor");
                else
                {
                    Mayor multa;
                    multa = new Mayor((Conductor)lb_conductores.SelectedItem, 15, of_transito.Salario_vigente,
                        (Mayor.l_inf_mayores)Enum.Parse(typeof(Mayor.l_inf_mayores), cbo_may.Text));

                    MessageBox.Show(multa.Anular_licencia());
                    MessageBox.Show(multa.Asignar_trabajo_social());
                    of_transito.Registrar_multa(multa);


                    lb_multas.DataSource = null;
                    
                    
                    lb_multas.DataSource = of_transito.L_multas;

                    lb_conductores.DataSource = null;
                    lb_conductores.DataSource = l_cond;

                    Set_recaudos();
                }

            }
            catch (Exception error)
            {
                throw new Exception("Error en multar mayor\n" + error);
            }

        }

        private void Set_recaudos()
        {
            try
            {
                ulong[] v_recaudos = of_transito.Calcular_din_multas();
                tb_total_mayores.Text = v_recaudos[1].ToString("C2");
                tb_total_menores.Text = v_recaudos[0].ToString("C2");
            }
            catch (Exception error)
            {
                throw new Exception("Error en calcular recaudos\n" + error);
            }
        }

        private void b_multar_menor_Click(object sender, EventArgs e)
        {
            try
            {
                if (lb_conductores.SelectedIndex == -1)
                    MessageBox.Show("Debe seleccionar un conductor");
                else
                {
                    Menor multa;
                    multa = new Menor((Conductor)lb_conductores.SelectedItem, 3, of_transito.Salario_vigente,
                        (Menor.l_inf_menores)Enum.Parse(typeof(Menor.l_inf_menores), cbo_men.Text));

                    of_transito.Registrar_multa(multa);
                    MessageBox.Show("Le quedan en la licencia un total de puntos \n" + 
                        multa.restar_puntos().ToString());

                    lb_multas.DataSource = null;
                    lb_multas.DataSource = of_transito.L_multas;

                    lb_conductores.DataSource = null;
                    lb_conductores.DataSource = l_cond;

                    Set_recaudos();
                }

            }
            catch (Exception error)
            {
                throw new Exception("Error en multar menor\n" + error);
            }

        }
    }
}
