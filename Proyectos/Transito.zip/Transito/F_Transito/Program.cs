﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using b_Transito.Clases;

namespace F_Transito
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new f_multas());
            }
            catch (Exception error)
            {
                MessageBox.Show("Ocurrió un error\n" + error);
            }

        }
    }
}
