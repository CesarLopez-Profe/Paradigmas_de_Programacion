﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b_Transito.Clases
{
    public class Conductor
    {
        public enum l_ids {CC, TI, PAS, CE};
        public enum l_estados {Activa, Suspendida};

        private l_ids tipo_id;
        private string nro_id;
        private string nombre_completo;
        private byte edad;
        private string nro_licencia;

        private l_estados estado_licencia = l_estados.Activa;
        private uint ptos_licencia = 50000;


        //Accesores
        public string Nro_id { get => nro_id; set => nro_id = value; }
        public string Nombre_completo { get => nombre_completo; set => nombre_completo = value; }
        public byte Edad { get => edad; set => edad = value; }
        public l_ids Tipo_id { get => tipo_id; set => tipo_id = value; }
        public string Nro_licencia { get => nro_licencia; }
        internal l_estados Estado_licencia { get => estado_licencia; set => estado_licencia = value; }
        internal uint Ptos_licencia { get => ptos_licencia; set => ptos_licencia = value; }


        //Constructor
        public Conductor(l_ids tipo_id, string nro_id, string nombre_completo, byte edad)
        {
            this.Tipo_id = tipo_id;
            this.Nro_id = nro_id;
            this.Nombre_completo = nombre_completo;
            this.Edad = edad;

            Random aleatorio = new Random();
            this.nro_licencia = "LIC" + aleatorio.Next(200000, 999999);

        }

        public override string ToString()
        {
            return nombre_completo + " | "  + estado_licencia.ToString() + " | " + ptos_licencia.ToString("N0");
        }
    }
}
