﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using b_Transito.Interfaces;

namespace b_Transito.Clases
{
    public abstract class Multa
    {
        private ulong codigo;
        private Conductor conductor;
        private DateTime fecha_hora;
        private ulong valor;
        protected byte cant_salarios;
 
        public Multa(Conductor conductor, byte cant_salarios, ulong valor_salario)
        {
            Random aleatorio = new Random();
            codigo = (ulong)aleatorio.Next(46661,6641651);
            this.conductor = conductor;
            fecha_hora = DateTime.Now;
            Cant_salarios = cant_salarios;
            valor = (ulong)(cant_salarios * valor_salario);

        }

        public ulong Codigo { get => codigo; }
        public Conductor Conductor { get => conductor; set => conductor = value; }
        public DateTime Fecha_hora { get => fecha_hora; }
        public ulong Valor { get => valor; }
        public abstract byte Cant_salarios { get; set; }


        public ulong Imponer_sancion(ulong sal_min)
        {
            try
            {
                ulong val_retornar = sal_min * cant_salarios;
                return val_retornar;
            }
            catch (Exception error)
            {
                throw new Exception("Ocurrió un error en Imponer Sanción menor \n" + error);
            }

        }


    }
}
