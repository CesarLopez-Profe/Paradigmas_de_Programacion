﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b_Transito.Clases
{
    public class Menor : Multa
    {
 
        public enum l_inf_menores { Mal_Estacionado, Luces, Exceso_Velocidad };
        private l_inf_menores infraccion;

        public Menor(Conductor conductor, byte cant_salarios, ulong valor_salario ,l_inf_menores infraccion) : 
            base(conductor, cant_salarios, valor_salario)
        {
            Cant_salarios = cant_salarios;
            this.infraccion = infraccion;
        }

        public override byte Cant_salarios
        {
            get => cant_salarios;
            set
            {
                if (value != 3)
                    throw new Exception("La cantidad de salarios en la multa menor debe ser 3");
                else
                    cant_salarios = value;
            }
        }

        public uint restar_puntos()
        {
            try
            {
                if (Conductor.Ptos_licencia >= 1000 &&
                    Conductor.Estado_licencia == Conductor.l_estados.Activa)
                {

                    if (Conductor.Ptos_licencia - 1000 == 0)
                        Conductor.Estado_licencia = Conductor.l_estados.Suspendida;

                    return (Conductor.Ptos_licencia -= 1000);
                }
                else
                    throw new Exception("El conductor está con licencia suspendida o no tiene puntos para restar");
            }
            catch(Exception error)
            {
                throw new Exception("Se presentó un error en restar puntos multa menor\n" + error);
            }
        }

        public override string ToString()
        {
            return Conductor.Nombre_completo + "|" + infraccion.ToString() + "| " + Valor.ToString("C2");
        }

    }
}
