﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b_Transito.Clases
{
    public class Transito
    {
        private ulong salario_vigente;
        private List<Multa> l_multas = new List<Multa>();

        public List<Multa> L_multas { get => l_multas;  }
        public ulong Salario_vigente { get => salario_vigente;  }

        public Transito(ulong salario_vigente)
        {
            this.salario_vigente = salario_vigente;
        }

        public bool Registrar_multa(Multa multa)
        {
            try
            {
                L_multas.Add(multa);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public ulong[] Calcular_din_multas()
        {
            try
            {
                ulong[] vector_retornar = new ulong[2];
                vector_retornar[0] = 0;
                vector_retornar[1] = 0;

                foreach(Multa elemento in L_multas)
                {
                    if (elemento is Menor)
                        vector_retornar[0] += elemento.Valor;
                    else
                        vector_retornar[1] += elemento.Valor;
                }
                return vector_retornar;

            }

            catch(Exception error)
            {
                throw new Exception("Ocurrió un error calculando dinero multas\n" + error);
            }
        }
    }
}
