﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b_Transito.Clases
{
    public class Mayor: Multa
    {
        public enum l_inf_mayores {SOAT_vencido,TecnicoMecanica_Vencida,Embriaguez};
        private l_inf_mayores infraccion;

        public Mayor(Conductor conductor, byte cant_salarios, ulong valor_salario, l_inf_mayores infraccion) :
           base(conductor, cant_salarios, valor_salario)
        {
            Cant_salarios = cant_salarios;
            this.infraccion = infraccion;
        }

        public override byte Cant_salarios
        {
            get => cant_salarios;
            set
            {
                if (value != 15)
                    throw new Exception("La cantidad de salarios en la multa mayor debe ser 15");
                else
                    cant_salarios = value;
            }
        }

        public string Asignar_trabajo_social()
        {
            try
            {
                Random alea = new Random();
                switch (alea.Next(1, 3))
                {
                    case 1: return "Trabajo social Biblioteca";
                    case 2: return "Trabajo social Parques";
                    case 3: return "Trabajo social Ciclovia";
                    default: return "Opcion no válida";  

                }
            }
            catch(Exception error)
            {
                throw new Exception("Ocurrió error en asignación de trabajo, multa mayor \n" + error);
            }
        }

        public string Anular_licencia()
        {
            try
            {
                if (Conductor.Estado_licencia == Conductor.l_estados.Activa)
                {
                    Conductor.Estado_licencia = Conductor.l_estados.Suspendida;
                    Conductor.Ptos_licencia = 0;
                    return "La licencia ha quedado anulada y los puntos en 0";
                }
                else
                    return "El conductor ya tiene la licencia suspendida, detengalo!!!";
            }
            catch (Exception error)
            {
                throw new Exception("Ocurrió un error anulando licencia, multa mayor " + error);
            }
        }

        public override string ToString()
        {
            return Conductor.Nombre_completo + "|" + infraccion.ToString() + "| " + Valor.ToString("C2");
        }
    }
}
