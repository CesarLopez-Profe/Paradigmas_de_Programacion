﻿// See https://aka.ms/new-console-template for more information
using p_multiplexquiz2.Clases;
using System;

try
{
    Agua brisa_200 = new Agua("Agua Brisa 200", 10500, 200);
    Agua brisa_600 = new Agua("Agua Brisa 600", 14000, 600);
    Gaseosa gas_grande = new Gaseosa("Gaseosa Tamaño Grande", 19000, Gaseosa.enum_tamano.Grande);
    Crispeta cris_salada = new Crispeta("Cubeta crispeta salada", 25000, Crispeta.enum_sabor.Saladas);

    List<Producto> l_prod_conf = new List<Producto>();

    l_prod_conf.Add(brisa_600);
    l_prod_conf.Add(brisa_200);
    l_prod_conf.Add(gas_grande);
    l_prod_conf.Add(cris_salada);

    Multiplex unicentro = new Multiplex("Cine Colombia Unicentro", l_prod_conf);

    unicentro.L_taquillas.Add(new Taquilla(1, new Taquillero("Juan Perez", 64455642, 3125852146)));
    unicentro.L_taquillas.Add(new Taquilla(2, new Taquillero("Susana Martinez", 98904033, 3145667097)));
    unicentro.L_taquillas.Add(new Taquilla(3, new Taquillero("Miguel Escobar", 45676033, 3156778108)));

    //Se quiere vender en una taquilla específica
    //se usa var para manejar el nulo, si se pone Taquilla paila
    var taq1 = unicentro.L_taquillas.FirstOrDefault(t => t.Nro == 1);
    var taq2 = unicentro.L_taquillas.FirstOrDefault(t => t.Nro == 2);
    var taq3 = unicentro.L_taquillas.FirstOrDefault(t => t.Nro == 3);

    Sala sala1 = new Sala(1, 20, 50);
    Sala cinebar = new Sala(2, 50, 10);

    Pelicula ToyStory4 = new Pelicula("Toy Story IV", "Toy Story IV", new TimeSpan(2, 0, 0), 6);
    Pelicula _4Fantasticos = new Pelicula("Fantastic Four", "Los Cuatro Fantásticos", new TimeSpan(1, 35, 0), 12);

    Funcion fun1 = new Funcion(sala1, _4Fantasticos, new DateTime(2025, 10, 15, 14, 0, 0));
    Funcion fun2 = new Funcion(sala1, _4Fantasticos, fun1.Hora_final.AddMinutes(5));
    Funcion fun3 = new Funcion(sala1, _4Fantasticos, fun2.Hora_final.AddMinutes(5));
    Funcion fun4 = new Funcion(sala1, _4Fantasticos, fun3.Hora_final.AddMinutes(5));

    unicentro.Agregar_funcion(fun1);
    unicentro.Agregar_funcion(fun2);
    unicentro.Agregar_funcion(fun3);
    unicentro.Agregar_funcion(fun4);

    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine("Películas en el Multiplex de Unicentro\n");
    Console.ResetColor();

    for (int fun = 0; fun < unicentro.L_funciones.Count; fun++)
    {
        Console.WriteLine($"{fun}: {unicentro.L_funciones[fun].ToString()}\n");
    }


    //Vender Boletas
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine("Se va a vender boleta en la taquilla 1\n");
    Console.ResetColor();

    if (taq1.Abierta)
    {
        Console.WriteLine("Se va a simular la venta de dos boletas para general en efectivo");
        Console.WriteLine(taq1.Vender_boleta(unicentro.L_funciones.ElementAt(0), 2, Multiplex.tipo_sillas.G, new Espectador("Mauricio Arias", 8090904049, 3113119900), new Efectivo()));

        Console.WriteLine("Se va a simular la venta de 1 boleta para general con débito");
        Console.WriteLine(taq1.Vender_boleta(unicentro.L_funciones.ElementAt(1), 1, Multiplex.tipo_sillas.G, new Espectador("Valentina ", 1085985225, 3224220011), new Tarjeta("Bancolmbia", 89752368521, Tarjeta.tipo_tarjeta.Débito)));

        Console.WriteLine("Se va a simular la venta de 1 boleta para VIP con membresía");
        Socio valeria = new Socio("Valeria ", 1085985225, 3224220011);
        Console.WriteLine(taq1.Vender_boleta(unicentro.L_funciones.ElementAt(1), 1, Multiplex.tipo_sillas.V, valeria, new Membresia(5554422351,valeria)));
    }

    else
    {
        Console.ForegroundColor = ConsoleColor.DarkRed;
        Console.WriteLine("La taquilla 1 está cerrada\n");
        Console.ResetColor();
    }

    Console.ForegroundColor = ConsoleColor.Blue;
    Console.WriteLine("Estado después de la venta\n");
    Console.ResetColor();

    for (int fun = 0; fun < unicentro.L_funciones.Count; fun++)
    {
        Console.WriteLine($"{fun}: {unicentro.L_funciones[fun].ToString()}");
    }

    //Ahora vamos a la dulcería  a comprar productos
    List<Producto> l_pedido_dulceria = new List<Producto>();
    l_pedido_dulceria.Add(brisa_600);
    l_pedido_dulceria.Add(brisa_600);
    l_pedido_dulceria.Add(brisa_600);
    l_pedido_dulceria.Add(cris_salada);

    Console.WriteLine("=====COMPRA EN DULCERIA=======");
    Console.WriteLine(unicentro.Dulceria.VenderProducto(l_pedido_dulceria, new Efectivo()));
    Console.WriteLine("\n");




    //Console.WriteLine(taq1.Vender_boleta(fun1, 1, Multiplex.tipo_sillas.V, new Socio("Valeria Rendon",1090904049, 3184220011)));

    Console.ReadKey();

    /*
    List<Producto> l_prod_vend = new List<Producto>();

    l_prod_vend.Add(brisa_600);
    l_prod_vend.Add(brisa_600);
    l_prod_vend.Add(brisa_200);
    l_prod_vend.Add(cris_salada);
    */




    Console.ReadKey();
}

catch (Exception error) {
    Console.WriteLine(error.Message);
}




