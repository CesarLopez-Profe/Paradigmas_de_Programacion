﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_multiplexquiz2.Clases
{
    internal class Dulceria
    {
        private bool abierta;
        private List<Producto> l_productos_vende;

        public Dulceria(List<Producto> l_productos_vende)
        {
            Abierta = true;
            this.l_productos_vende = l_productos_vende;
        }

        public bool Abierta { get => abierta; set => abierta = value; }

        public string VenderProducto(List<Producto> l_productos_vta, Pago pago)
        {
            try
            {
                string info_del_pago="";
                uint valor_pagado = 0;
                if (Abierta)
                {
                    string detalle = string.Join("",
                        l_productos_vta
                        .GroupBy(p => p.Descripcion)
                        .Select(g => $"{g.Count()} {g.Key}:{g.Sum(p => (decimal)p.Valor).ToString("C0")}  \n"));

                    decimal totalVenta = l_productos_vta.Sum(p => (decimal)p.Valor);

                    Console.WriteLine($"{detalle}\nEl valor a pagar es: {((uint)totalVenta).ToString("C0")}\n");

                    if (pago is Tarjeta || pago is Membresia)
                    {
                        info_del_pago += ($"\nPago Exitoso: {pago.Procesar_pago((uint)totalVenta, (uint)totalVenta).exitoso}");
                        info_del_pago += ($"\nDevuelta: {pago.Procesar_pago((uint)totalVenta, (uint)totalVenta).devuelta.ToString("C0")}"); //Paga exacto
                    }
                    else if (pago is Efectivo)
                    {

                        Console.WriteLine("Ingrese el valor pagado por la persona: ");
                        valor_pagado = uint.Parse(Console.ReadLine());
                        info_del_pago += ($"\nPago Exitoso: {pago.Procesar_pago((uint)totalVenta, valor_pagado).exitoso}");
                        info_del_pago += ($"\nDevuelta: {pago.Procesar_pago((uint)totalVenta, valor_pagado).devuelta.ToString("C0")}"); //Paga exacto

                    }
                    return info_del_pago;
                }
                else
                    throw new Exception("La dulcería está cerrada");
            }
            catch (Exception ex)
            {
                throw new Exception("Error inesperado en la dulcería\n" + ex.ToString());
            }
        }
    }
}
