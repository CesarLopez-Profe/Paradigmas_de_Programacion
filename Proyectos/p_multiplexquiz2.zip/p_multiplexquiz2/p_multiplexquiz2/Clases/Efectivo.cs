﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_multiplexquiz2.Clases
{
    internal class Efectivo:Pago
    {
        public Efectivo() { }

        
        public override ResultadoPago Procesar_pago(uint monto_a_pagar, uint monto_pagado)
        {
            if (monto_a_pagar == monto_pagado) return new ResultadoPago(true); //no se pone la devuelta porque por defecto es cero
            else if (monto_pagado > monto_a_pagar) 
                return new ResultadoPago(true,monto_pagado - monto_a_pagar);
            else return new ResultadoPago(false);

                /*Esto se podría ver como:
                public uint ProcesarPagoConCambio(uint aPagar, uint pagado)
            => (pagado >= aPagar) ? (pagado - aPagar) : 0;*/
        }
    }
}
