﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_multiplexquiz2.Clases
{
    public class Funcion
    {
        private static uint consecutivo_funciones_gral=0;
        private uint consecutivo_func;
        private Sala sala;
        private Pelicula pelicula;
        private DateTime hora_inicio;
        private DateTime hora_final;
        private short nro_sill_ven_v = 0;
        private short nro_sill_ven_g = 0;



        public Funcion(Sala sala, Pelicula pelicula, DateTime hora_inicio)
        {
            consecutivo_func = consecutivo_funciones_gral;
            consecutivo_funciones_gral ++;
            this.sala = sala;
            this.pelicula = pelicula;
            this.hora_inicio = hora_inicio;
            hora_final = hora_inicio + Multiplex.aseo + Multiplex.cortos + pelicula.Duracion;
        }

        public uint Consecutivo { get => consecutivo_func;  }
        public DateTime Hora_inicio { get => hora_inicio;  }
        public DateTime Hora_final { get => hora_final;  }
        internal Sala Sala { get => sala; }
        internal Pelicula Pelicula { get => pelicula; }

        internal short Nro_sill_ven_v
        {
            get => nro_sill_ven_v;
            set
            {
                if (value > 0 && (nro_sill_ven_v + value) <= sala.Nro_sillas_v)
                    nro_sill_ven_v += value;
                else
                    throw new Exception("No especificó el número de sillas o " +
                        "no se pueden vender el nro de sillas solicitado para VIP, " +
                        "no hay suficientes sillas");
            }
        }
        internal short Nro_sill_ven_g
        {
            get => nro_sill_ven_g;

            set
            {
                if (value > 0 && (nro_sill_ven_g + value) <= sala.Nro_sillas_g)
                    nro_sill_ven_g += value;
                else
                    throw new Exception("No especificó el número de sillas o " +
                         "no se pueden vender el nro de sillas solicitado para GENERAL, " +
                         "no hay suficientes sillas");

            }

        }

        public override string ToString()
        {
            return $"\u001b[33mFuncion # {consecutivo_func} Hora inicio: {hora_inicio} Hora Final: {hora_final} \u001b[0m \n" +
                $"Pelicula: {pelicula.Nombre_espanol} \n" +
                $"{this.sala}\n" +
                $" Cantidad sillas vendidas General {nro_sill_ven_g}  \t Cantidad sillas Vendidas VIP {nro_sill_ven_v}\n";
        }


    }
}
