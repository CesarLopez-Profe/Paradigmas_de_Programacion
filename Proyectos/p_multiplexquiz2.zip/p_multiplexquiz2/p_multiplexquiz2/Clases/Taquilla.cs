﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_multiplexquiz2.Clases
{
    public class Taquilla
    {
        private byte nro;
        private Taquillero taquillero;
        private bool abierta = false;
        private List<Venta> l_ventas;

        public Taquilla(byte nro, Taquillero taquillero)
        {
            Nro = nro;
            this.taquillero = taquillero;
            abierta = true;
            //instanciar una lista para poder operarla
            l_ventas = new List<Venta>();
        }

        public byte Nro { get => nro; set
            {
                if (value <= 0 || value > 5) throw new Exception("Error en el nro de la taquilla");
                else nro = value;
            }
        
        }
        public bool Abierta { get => abierta; set => abierta = value; }
        internal Taquillero Taquillero { get => taquillero; }
        internal List<Venta> L_ventas { get => l_ventas; }

        public string Vender_boleta(Funcion funcion, byte cantidad, Multiplex.tipo_sillas tipo_silla, Persona persona, Pago pago)
        {
            try
            {
                string tirilla_boletas="";
                uint cantidad_a_pagar = 0, valor_pagado=0;
                Boleta bol;
                bool pago_ok = false;

                //Venta en General

                if (abierta && cantidad > 0 && cantidad <= Multiplex.cant_max_vta_bol
                    && funcion.Hora_inicio.Date >= DateTime.Today.Date && tipo_silla == Multiplex.tipo_sillas.G
                    && funcion.Nro_sill_ven_g + cantidad <= funcion.Sala.Nro_sillas_g)
                {

                    cantidad_a_pagar = (uint)(cantidad * Multiplex.vlr_bol_g);
 
                    if (pago is Tarjeta || pago is Membresia)
                    {
                        tirilla_boletas += ($"\nPago Exitoso: {pago.Procesar_pago(cantidad_a_pagar, cantidad_a_pagar).exitoso}");
                        tirilla_boletas += ($"\nDevuelta: {pago.Procesar_pago(cantidad_a_pagar, cantidad_a_pagar).devuelta}"); //Paga exacto
                        pago_ok = true;
                    }
                    else if (pago is Efectivo)
                    {

                        Console.WriteLine($"El valor a pagar es: {cantidad_a_pagar.ToString("C0")}\n");
                        Console.WriteLine("Ingrese el valor pagado por la persona: ");
                        valor_pagado = uint.Parse(Console.ReadLine());
                    
                        if ( valor_pagado > 0 && valor_pagado >= cantidad_a_pagar)
                        {
                            tirilla_boletas += ($"\nPago Exitoso: {pago.Procesar_pago(cantidad_a_pagar, valor_pagado).exitoso}");
                            tirilla_boletas += ($"\nDevuelta: {pago.Procesar_pago(cantidad_a_pagar, valor_pagado).devuelta.ToString("C0")}"); //Paga exacto
                            pago_ok=true;
                        }
                    }

                    if (pago_ok)
                    {
                        funcion.Nro_sill_ven_g += cantidad;
                        return GenerarBoletas(cantidad, funcion, persona, tipo_silla);
                    }
                    else
                        return "El pago no se pudo realizar. No se imprimen boletas \n";

                }

                //Venta en VIP

                else if (abierta && cantidad > 0 && cantidad <= Multiplex.cant_max_vta_bol
                    && funcion.Hora_inicio.Date >= DateTime.Today.Date && tipo_silla == Multiplex.tipo_sillas.V
                    && funcion.Nro_sill_ven_v + cantidad <= funcion.Sala.Nro_sillas_v)
                {

                    cantidad_a_pagar = (uint)(cantidad * Multiplex.vlr_bol_v);

                    if (pago is Tarjeta || pago is Membresia)
                    {
                        tirilla_boletas += ($"\nPago Exitoso: {pago.Procesar_pago(cantidad_a_pagar, cantidad_a_pagar).exitoso}");
                        tirilla_boletas += ($"\nDevuelta: {pago.Procesar_pago(cantidad_a_pagar, cantidad_a_pagar).devuelta.ToString("C0")}"); //Paga exacto
                        pago_ok = true;
                    }
                    else if (pago is Efectivo)
                    {
                        Console.WriteLine($"El valor a pagar es: {cantidad_a_pagar.ToString("C0")}\n");
                        Console.WriteLine("Ingrese el valor pagado por la persona: ");
                        valor_pagado = uint.Parse(Console.ReadLine());
                        if( valor_pagado > 0 && valor_pagado >= cantidad_a_pagar)
                        {
                            tirilla_boletas += ($"\nPago Exitoso: {pago.Procesar_pago(cantidad_a_pagar, valor_pagado).exitoso}");
                            tirilla_boletas += ($"\nDevuelta: {pago.Procesar_pago(cantidad_a_pagar, valor_pagado).devuelta}"); //Paga exacto
                            pago_ok = true;
                        }
                        else
                            return "El pago no se pudo realizar. No se imprimen boletas \n";

                    }

                    if (pago_ok)
                    {
                        funcion.Nro_sill_ven_v += cantidad;
                        return GenerarBoletas(cantidad,funcion, persona, tipo_silla);
                    }
                    else return ("El pago no se pudo realizar");
                }
                else
                    return ("No se registro la venta de las boletas por una de las siguientes situaciones: " +
                        "La taquilla está cerrada, o la cantidad de boletas a comprar no es correcta o la fecha de la " +
                        "función no está vigente o no hay sillas disponibles");

            }
            catch (Exception e)
            {
                throw new Exception("Ocurrió un error en el método vender boleta\n" + e );
            }
        }

        private string GenerarBoletas(uint cantidad, Funcion funcion, Persona persona, Multiplex.tipo_sillas tipo_silla)
        {
            try
            {
                string tirilla_boletas="";
                Boleta bol;

                for (byte i = 1; i <= cantidad; i++)
                    {
                    //Se concatena a la tirilla que se va a retornar, la info de la boleta
                    bol = new Boleta(funcion, persona, tipo_silla);
                    tirilla_boletas += ("\n************** BOLETA SILLA "+ tipo_silla.ToString().ToUpper() +" ******************"
                        + "\nBoleta nro: " + bol.Consecutivo
                        + "\nSala: " + bol.Funcion.Sala.Nro
                        + "\nPelicula: " + bol.Funcion.Pelicula.Nombre_espanol
                        + "\nFecha: " + bol.Funcion.Hora_inicio.ToShortDateString()
                        + "\nHora de Inicio: " + bol.Funcion.Hora_inicio.ToShortTimeString());
                        if (persona is Socio socio) tirilla_boletas += $"Socio: {socio.Nombre} Nro VIP: {socio.Nro_vip} ";
                        tirilla_boletas += ("\n********************************************************\n");
                    }
                    return tirilla_boletas;
            }
            catch (Exception e)
            {
                throw new Exception("Ocurrió un error en el método Generar boletas\n" + e);
            }
        }
        public override bool Equals(object? obj)
        {
            var taquilla_in = obj as Taquilla;

            if (taquilla_in != null)
            {
                return taquilla_in.Nro == nro;
            }
            return false;

        }

    }
}
