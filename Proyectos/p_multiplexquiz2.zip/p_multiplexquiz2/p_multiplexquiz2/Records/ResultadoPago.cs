﻿namespace p_multiplexquiz2
{
    public record ResultadoPago(bool exitoso, uint devuelta=0);
}
