﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_parque.Clases
{
    internal class Registro
    {
        Atraccion atraccion;
        Manilla manilla;
        DateTime fecha_hora;

        internal Registro(Atraccion atraccion, Manilla manilla)
        {
            this.atraccion = atraccion;
            this.manilla = manilla;
            fecha_hora = DateTime.Now;
        }

        public DateTime Fecha_hora { get => fecha_hora; }
        internal Atraccion Atraccion { get => atraccion;  }
        internal Manilla Manilla { get => manilla;  }
    }
}
