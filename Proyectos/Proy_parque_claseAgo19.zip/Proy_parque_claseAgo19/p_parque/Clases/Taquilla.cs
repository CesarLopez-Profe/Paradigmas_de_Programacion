﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_parque.Clases
{
    internal class Taquilla
    {
        private byte id;
        private List<Manilla> l_manillas_disp;
        private List<Manilla> l_manillas_vend;
        private ulong saldo_dinero;
        private bool abierta;

        public Taquilla(byte id)
        {
            this.Id = id;
            L_manillas_disp = new List<Manilla>();

            for (ushort i = 1; i <= 100; i++)
            {
                l_manillas_disp.Add(new Manilla());
            }

            l_manillas_vend = new List<Manilla>();
            saldo_dinero = 0;
            abierta = false;
        }

        public byte Id { get => id; 
            set => id = value >=1 && value <=3? value:
                throw new Exception("El id de la taquilla debe estar entre 1 y 3"); 
        }
        internal List<Manilla> L_manillas_disp { get => l_manillas_disp; 
            set => l_manillas_disp = value.Count <=100? value:
                throw new Exception("La lista de manillas disponibles no debe superar las 100");
        }

        public ushort ObtenerManillasVendidas()
        {
            return (ushort)l_manillas_vend.Count;
        }

        public Manilla VenderManillas(uint monto_dinero)
        {
            try
            {
                uint tot_ptos = 0;
                Manilla manilla_mover;

                if(monto_dinero >= 20000 && monto_dinero%500 == 0)
                {
                    tot_ptos = (monto_dinero - 4000) / 500;
                    if (l_manillas_disp.Count > 0)
                    {
                        manilla_mover = l_manillas_disp.ElementAt(0);
                        manilla_mover.Sdo_puntos =(ushort)tot_ptos;
                        l_manillas_vend.Add(manilla_mover);
                        l_manillas_disp.RemoveAt(0);
                        return manilla_mover;
                    }
                    else throw new Exception("No hay manillas disponibles en la taquilla " + id);
                }
                else
                {
                    throw new Exception("El monto mínimo son $20.000");
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Ocurrió un error en el método VenderManilla\n" + ex );
            }
        }
    }
}
