﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_parque.Clases
{
    internal class Manilla
    {
        private ulong id;
        private ushort sdo_puntos;

        internal Manilla()
        {
            Random aleatorio = new Random();
            id = (ulong)aleatorio.NextInt64(1000000, 10000000);
            Sdo_puntos = 0;
        }

        public ushort Sdo_puntos { get => sdo_puntos; 
            set => sdo_puntos = value>=0?value:
                throw new Exception ("El saldo no puede quedar por debajo de cero"); }
    }
}
