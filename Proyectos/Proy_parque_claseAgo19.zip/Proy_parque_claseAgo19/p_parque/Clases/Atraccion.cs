﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_parque.Clases
{
    internal class Atraccion
    {
        private string nombre;
        private byte ptos_ingresar;

        
        public Atraccion(string nombre, byte ptos_ingresar)
        {
            this.Nombre = nombre;
            this.Ptos_ingresar = ptos_ingresar;
        }

        internal string Nombre { get => nombre.ToUpper();
            set => nombre = !(String.IsNullOrWhiteSpace(value)||value.Length <= 5) ? value.ToUpper():
                throw new Exception($"El nombre {value} debe tener mínimo 5 caracteres y no puede ser espacios en blanco");               
                }

        internal byte Ptos_ingresar { get => ptos_ingresar; 
            
            set => ptos_ingresar = value >=10 && value <=30? value : throw new Exception($"El puntaje debe ser entre 10 y 30");

        }

        public Registro RegistrarIngreso(Manilla manilla)
        {
            try
            {
                if (manilla.Sdo_puntos >= ptos_ingresar)
                {
                    manilla.Sdo_puntos = (ushort)(manilla.Sdo_puntos - ptos_ingresar);
                    return new Registro(this,manilla);
                    //return true;
                }
                else throw new Exception($"No tiene saldo suficiente para ingresar");
            }
            catch (Exception ex) {
                throw new Exception($"Excepción no controlada en método Registrar ingreso\n" + ex);
            }

        }
        

        

    }
}
