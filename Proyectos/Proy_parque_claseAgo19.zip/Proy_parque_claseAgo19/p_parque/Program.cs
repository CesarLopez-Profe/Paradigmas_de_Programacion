﻿using p_parque.Clases;
// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

Taquilla taq1 = new Taquilla(1);

Manilla manilla_prueba = taq1.VenderManillas(50000);

Console.WriteLine($"La manilla de prueba quedó con un saldo de: {manilla_prueba.Sdo_puntos}");

Atraccion carrusel = new Atraccion("Carrusel", 10);

Registro reg1  = carrusel.RegistrarIngreso(manilla_prueba);

Console.WriteLine($"Manilla prueba pasó por la atracción {reg1.Atraccion.Nombre} en la fecha {reg1.Fecha_hora} y le quedaron {reg1.Manilla.Sdo_puntos}\n\n");

