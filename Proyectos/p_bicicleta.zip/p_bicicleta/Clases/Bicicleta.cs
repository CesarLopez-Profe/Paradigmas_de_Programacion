﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_bicicleta.Clases
{
    internal class Bicicleta
    {
        //enums
        public enum l_marcos {S,M,L,XL};
        public enum l_materiales { Carbono, Titanio, Aluminio };
        public enum l_colores { Negro, Blanco, Cromo};

        //atributos de usuario
        public l_marcos marco;
        public l_materiales material;
        public l_colores color;
        private float tam_llanta;
        private byte cantidad_cambios;

        //atributos de estado
        private byte cambio_actual;
        private byte vel_actual;

        //atributos de reglas : ESTOS LOS VAMOS A SACAR DE ACÁ LUEGO
        //Llevan el valor asociado
        public const byte cambio_min = 7;
        public const byte cambio_max = 9;
        public const byte cambio_inic = 1;
        public const byte vel_min = 0, vel_max = 100;
        public const byte tam_llan_min = 16, tam_llan_max = 29;

        
        //métodos constructores
        public Bicicleta()
        {
            //Se inicializan los atributos de usuario que apliquen
            //NUNCA NUNCA NUNCA van a validar atributos de usuario en el constructor
            cambio_actual = cambio_inic;
            vel_actual = vel_min;
            Tam_llanta = tam_llan_min;
        }

        public Bicicleta(l_marcos marco, l_materiales material, l_colores color, 
            float tam_llanta, byte cantidad_cambios)
        {
            this.marco = marco;
            this.material = material;
            this.color = color;
            Tam_llanta = tam_llanta;
            Cantidad_cambios = cantidad_cambios;
            cambio_actual = cambio_inic;
            vel_actual = vel_min;
        }


        //métodos de encapsulamiento
        public float Tam_llanta
        {
            get => tam_llanta;

            set
            {
                tam_llanta = value >= tam_llan_min && value <= tam_llan_max ? value :
                    throw new Exception($"El tamaño {value} de llanta no es válido");
            }
        }

        public byte Cantidad_cambios
        {
            get => cantidad_cambios;
            set
            {
                cantidad_cambios = value >= cambio_min && value <= cambio_max ? value :
                    throw new Exception($"La cantidad de cambios {value} no es válida");
            }
        }

        //métodos de comportamiento con void

        public void SubirCambio() { if (cambio_actual < cantidad_cambios) cambio_actual++; }
        public void BajarCambio() { if (cambio_actual > cambio_inic) cambio_actual--; }
        public void Acelerar(byte vel_obj) { if (vel_obj > vel_actual && vel_obj<=vel_max) vel_actual = vel_obj; }
        public void Frenar(byte vel_obj) { if (vel_actual>vel_obj && vel_obj >= vel_min ) vel_actual = vel_obj; }

	//métodos de comportamiento con lambda
	/*
	public byte Subir_cambio() => cambio_actual < camb_max && en_movimiento ? cambio_actual++ : cambio_actual;
        public byte Bajar_cambio() => cambio_actual > camb_min && en_movimiento ? cambio_actual-- : cambio_actual;
        public bool Rodar() => !en_movimiento ? en_movimiento = true : en_movimiento;
        public bool Frenar() => en_movimiento ? en_movimiento = false : en_movimiento;
	*/

        //override de métodos sys
        public override string ToString()
        {
            return $"BICICLETA {this.GetType().Name}\n; {marco}, {color}, {material}\nVelocidad Actual: {vel_actual} " +
                $"Cambio Actual: {cambio_actual}";
        }

    }
}
