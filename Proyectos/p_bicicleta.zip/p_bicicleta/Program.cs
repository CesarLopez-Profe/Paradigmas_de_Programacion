﻿using p_bicicleta.Clases;

namespace p_bicicleta
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {

                Bicicleta GW = new Bicicleta();
                GW.material = Bicicleta.l_materiales.Titanio;
                GW.color = Bicicleta.l_colores.Negro;
                GW.marco = Bicicleta.l_marcos.M;
                GW.Cantidad_cambios = 7;
                GW.Tam_llanta = 23;

                Bicicleta Trek = new Bicicleta(Bicicleta.l_marcos.L, Bicicleta.l_materiales.Carbono,
                    Bicicleta.l_colores.Cromo, 27, 9);

                //Console.WriteLine($"{GW.GetHashCode()}\t{Trek.GetHashCode()}");
                //Console.WriteLine($"{GW.GetType()}\t{Trek.GetType()}");

                Trek.Acelerar(5);
                Trek.SubirCambio();
                Trek.SubirCambio();
                Trek.Acelerar(10);

                Console.WriteLine($"{GW.ToString()}\n\n{Trek.ToString()}");

            }
            catch (Exception ex) {Console.WriteLine(ex.Message.ToString());}
        }
    }
}
