﻿// See https://aka.ms/new-console-template for more information
// Console.WriteLine("Hello, World!");

// Forma clásica de declarar una lista de puntos
List<int> puntos = new List<int>();

Random random = new Random();
for (int i = 0; i < 500; i++)
{
    puntos.Add(random.Next(1000, 9999));
}

// declare una funcion lambda booleana para saber si en la lista puntos contiene algún ítem que sea igual a 5000

bool contiene(int ptos_buscar) => puntos.Contains(ptos_buscar);

Console.WriteLine(contiene(5000));
Console.WriteLine(contiene(2500));

puntos.Add(5000);
Console.WriteLine(contiene(5000));

//queremos saber si en la lista puntos hay al menos (any) número que sea mayor a 9000
bool mayor_a_9000(int ptos_buscar) => puntos.Any(p => p > ptos_buscar);
Console.WriteLine(mayor_a_9000(9000));

//queremos saber si en la lista todos (all) los elementos cumplen una condición 
bool todos_mayores_a_(int nro) => puntos.All(p => p > nro);
Console.WriteLine(todos_mayores_a_(1000));


//Select, SelectMany, and Zip

//Select
var ptos_bonificados_l = puntos.Select(p => p + 1000).ToList(); //Deja en una lista
var ptos_bonificados_r = puntos.Select(p => p + 1000).ToArray(); //Deja en un array

Console.WriteLine(string.Join("-", ptos_bonificados_l));

//Zip, unimos la lista de puntos con la de puntos bonificados
var ptos_combinados = puntos.Zip(ptos_bonificados_l, (p, pb) => $"{p} - {pb} \n").ToList();
Console.WriteLine(string.Join("",ptos_combinados));

//Where and OfType

var puntos_vip = puntos.Where(p => p > 9000).ToList();
Console.WriteLine(string.Join("-", puntos_vip));

Console.WriteLine();

var ptos_string = puntos.OfType<int>().ToList();
Console.WriteLine(string.Join("-", ptos_string));

Console.ForegroundColor = ConsoleColor.Yellow;
Console.WriteLine("Cantidad de la lista de puntos: " + puntos.Count);

//Distinct, elimina los duplicados
var puntos_sin_duplicados = puntos.Distinct().ToList();
Console.BackgroundColor = ConsoleColor.Blue;
Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine("Cantidad de la lista de puntos sin duplicados: " + puntos_sin_duplicados.Count);

//Except, elimina los elementos de una lista que están en otra lista
var puntos_sin_miles = puntos.Except(new List<int> { 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000 }).ToList();
Console.ResetColor();
Console.Clear(); //quita el fondo azul 

Console.WriteLine("\nCantidad de la lista de puntos sin miles: " + puntos_sin_duplicados.Count);

//Intersect, intersecta los elementos que hay en dos lostas
var puntos_intersectados = puntos.Intersect(new List<int> { 1111, 2222, 3333, 4444, 5555, 6666, 7777, 8888, 9999 }).ToList();
Console.ForegroundColor = ConsoleColor.Blue;
Console.WriteLine("\nPuntos Intersectados " + string.Join("-", puntos_intersectados));
Console.ResetColor();

//Union, une los elementos de dos listas sin duplicados
var puntos_unidos = puntos.Union(new List<int> { 1111, 2222, 3333, 4444, 5555, 6666, 7777, 8888, 9999 }).ToList();

Console.ForegroundColor = ConsoleColor.Green;
Console.WriteLine("\nPuntos unidos " + string.Join("-", puntos_unidos));
Console.ResetColor();

//OrderBy, OrderByDescending, ThenBy, ThenByDescending

//OrderBy --> por defecto ascending. También está OrderByDescending. Invertidos con reverse 
var puntos_ordenados = puntos.OrderBy(p => p).ToList();
Console.ForegroundColor = ConsoleColor.Cyan;
Console.WriteLine("\nPuntos ordenados " + string.Join("-", puntos_ordenados) + "\n");
Console.ResetColor();

//El ThenBy se usa para ordenar por más de un campo
var palabras = new List<string> { "Palma", "Palo", "Paloma", "Pi", "Pino", "Pinocho" };
var palabras_ordenadas = palabras.OrderBy(p => p.Length).ThenBy(p => p).ToList();
Console.ForegroundColor = ConsoleColor.Magenta;
Console.WriteLine("\nPalabras ordenadas " + string.Join("-", palabras_ordenadas) + "\n");
Console.ResetColor();

//Agregate: aplica función acumuladora  
List<int> puntos = new() { 1, 2, 3, 4, 5 };
int total_puntos = puntos.Aggregate((acumulador, elemento) => acumulador + elemento); // Result: 15
Console.WriteLine ("Puntos Acumulados" + total_puntos);
total_puntos = puntos.Aggregate((acumulador, elemento) => acumulador + elemento*2); // Result: 29
Console.WriteLine ("Puntos Acumulados con incremento" + total_puntos);

//Sum: suma los elementos
int suma_puntos = puntos.Sum(elemento => elemento);
Console.WriteLine ("Puntos Sumados" + suma_puntos);


//Count: Cuenta el número de elementos de una lista. Hay un longCount que devuelve un contador en long cuando se excede el número de elementos de un int
 Console.WriteLine ("Cantidad de elementos en la lista puntos " + puntos.Count());


//Average: Promedio
float ptos_prom = (float)puntos.Average(p => p);
Console.WriteLine ("Promedio puntos " + ptos_prom.ToString("F2"));

//Lista con los elementos que están por encima del promedio
var ptos_sobre_prom = puntos.Where(p => p>ptos_prom).ToList();
Console.WriteLine ("Cantidad de elementos en la lista de puntos sobre el promedio " + ptos_sobre_prom.Count());

//Min,Max
int min = puntos.Min(p => p);
Console.WriteLine("El mínimo de puntos es: " + min);

int max = puntos.Max(p => p);
Console.WriteLine("El máximo de puntos es: " + max);


//Combinación de Where con Select
var prueba = puntos.Where(p => p>=4 ).Select(p=>p).ToList();
Console.WriteLine ("Cantidad de elementos en la lista prueba " + prueba.Count());

//Otra forma de escribirlo:
var prueba1 = puntos
    .Where(p => p>=4 )
    .Select(p=>p)
    .ToList();

Console.WriteLine ("Cantidad de elementos en la lista prueba1 " + prueba1.Count());
