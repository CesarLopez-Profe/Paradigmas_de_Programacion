﻿using System.Data;
using System.Linq.Expressions;
using System.Security.Cryptography;

namespace p_reservas_26
{
    internal class Program
    {
        //variables globales
        static readonly byte cant_fil = 20, cant_sillxfil = 4, tam_min_cod_sill = 2, cant_max_reser = 5,
            letra_inicial = 65, letra_final = 68;
        static string[,] avion = new string[cant_fil, cant_sillxfil];
        static Random aleat = new Random();
        static readonly short nro_res_min = 1000, nro_res_max = 9999;
        static bool avion_inicializado = false;
        static byte opc;
        static uint cantidad_tot_sillas = (uint)(cant_fil * cant_sillxfil);

        static void Main(string[] args)
        {
            try
            {
                string codigo_silla;
                string[] v_sillas = { "2A", "2B", "16C", "16D", "16E" };
                byte nro_fila, cant_sillas;

                do
                {
                    try //bloque try catch para atrapar los errores del menu
                    {
                        Console.WriteLine("""
                                ******MENU********
                                1. Inicializar el Avión
                                2. Reservar una silla aleatoria
                                3. Reservar una silla con código (#Letra)
                                4. Reservar un grupo de sillas aleatorias 
                                5. Reservar un grupo de sillas con códigos 
                                6. Imprimir el estado del avión
                                7. Salir 
                                """);

                        Console.WriteLine("Seleccione su opción: ");


                        if (byte.TryParse(Console.ReadLine(), out opc))
                        {

                            switch (opc)
                            {

                                case 1:
                                    if (Inicializar_avion())
                                    {
                                        avion_inicializado = true;
                                        Console.WriteLine("El avión se inicializo exitosamente");
                                    }

                                    else Console.WriteLine("Hubo un problema al inicializar el avión, por favor revise ");
                                    break;

                                case 2:
                                    Console.WriteLine(Reservar_silla()); //una silla, la primera que encuentre libre
                                    break;
                                case 3:
                                    Console.WriteLine("Ingrese el codigo de la silla a reservar en formato #fila"); 
                                    codigo_silla = Console.ReadLine();
                                    Console.WriteLine(Reservar_silla(codigo_silla));
                                    break;
                                case 4:
                                    Console.WriteLine("Ingrese la cantidad de sillas que quiere reservar: "); //Tarea1: convertir a tryparse
                                    cant_sillas = byte.Parse(Console.ReadLine());
                                    Console.WriteLine(Reservar_silla(cant_sillas, Obtener_nro_reserva()));
                                    break;
                                case 5:
                                    Console.WriteLine(Reservar_silla(v_sillas));
                                    break;
                                case 6:
                                    Console.WriteLine(Imprimir_avion());
                                    break;
                                case 7:
                                    Console.WriteLine("Chao");
                                    break;
                                default:
                                    Console.WriteLine("Opción no válida");
                                    break;

                            }
                        }
                    }
                    catch(Exception err)
                    {
                        Console.WriteLine($"Ocurrió un error al ejecutar una opción del menú: \n{err.Message}");
                    }
                }
                while ((opc) != 7);
                

            }

            catch (Exception e)
            {
                Console.WriteLine($"Ocurrió un error : \n{e.Message}");
            }
        }

        //Métodos Auxiliares
        static (sbyte,sbyte) Convertir_silla_pos(string cod_silla)
        {
            try
            {

                char letra;
                sbyte fil = -1, col = -1;

                //Los códigos de silla siguen la siguiente estructura: nrofila+letra
                //por ejemplo: 1A equivale a la posición 0,0
                //12D equivale a la posición: 11,3

                if (cod_silla.Length >= tam_min_cod_sill)
                {
                    if ((char.TryParse(cod_silla.Substring(cod_silla.Length - 1), out letra))
                        && (byte)letra >= letra_inicial && (byte)letra <= letra_final
                        && sbyte.TryParse(cod_silla.Substring(0, cod_silla.Length - 1), out fil)
                        && fil >= 0 && fil <= cant_fil
                        )
                    {
                        col = (sbyte)(letra - letra_inicial); //Tarea: validar que realmente vengan letras en la ultima pos
                        fil = (sbyte)(fil - 1); //validar que la silla no se salga de la matriz
                    }
                    else throw new Exception($"Error en la silla reportada por el usuario {cod_silla}");
                    
                }

                return (fil, col);
            }

            catch (Exception e)
            {
                throw new Exception($"Ocurrió un error convirtiendo el código de la silla en la posición: \n{e.Message}");
            }
        }
        
        static string Convertir_pos_silla(byte fil, byte col)
        {
            try
            {

                if (fil <= cant_fil - 1 && col <= cant_sillxfil - 1)
                    return $"{fil + 1}{(char)(col + letra_inicial)}";
                else
                    throw new Exception($"La fila {fil} y la columna {col} están por fuera del rango de la matriz, " +
                        $"no es posible la conversión");
            }
            catch (Exception e)
            {
                throw new Exception($"Ocurrió un error convirtiendo la posición en el código de la silla: \n{e.Message}");
            }
        }

        
        static string Obtener_nro_reserva()
        {
            try
            {
                int n_reserva = aleat.Next(nro_res_min, nro_res_max);
                return ((char)(aleat.Next(letra_inicial, letra_inicial+25))).ToString() + "-" + n_reserva;
            }

            catch (Exception e) { throw new Exception($"Ocurrió un error en Obtener_nro_reserva\n{e.Message}"); }

        }

        //Método para inicializar el avión
        static bool Inicializar_avion()
        {
            try
            {
                for (int fil = 0; fil < avion.GetLength(0); fil++)
                {
                    for (int col = 0; col < avion.GetLength(1); col++)
                    {
                        avion[fil, col] = "L";
                    }
                }
                cantidad_tot_sillas = (uint)(cant_fil * cant_sillxfil);
                return true;
            }
            catch (Exception error)
            {
                throw new Exception($"Se presentó un error al inicializar el avión \n {error.Message}");
            }

        }

        //Método para reservar la primera silla libre en el avión
        static string Reservar_silla()
        {
            try
            {
                if (avion_inicializado == false) return "Para reservar una silla, el avión debe estar inicializado";
                              
                for (byte i = 0; i < avion.GetLength(0); i++)
                {
                    for (byte j = 0; j < avion.GetLength(1); j++)
                    {
                        if (avion[i, j].Equals("L"))
                        {
                            avion[i, j] = Obtener_nro_reserva();
                            cantidad_tot_sillas--;
                            return $"Le hemos asignado de forma aleatoria la silla {Convertir_pos_silla(i,j)} con el número " +
                                $"de reserva {avion[i,j]} ";
                        }
                    }

                }
                return "El avión esta lleno";
            }
            catch (Exception error)
            {
                throw new Exception($"Se presentó un error al reservar una silla aleatoria en el avión \n {error.Message}");
            }
        }

        //Método para reservar una silla en el avión con el código que quiere el pasajero 
        static string Reservar_silla(string codigo_silla)
        {
            try
            {
                var coordenadas = Convertir_silla_pos(codigo_silla);

                if (avion_inicializado == false || (coordenadas.Item1==-1 && coordenadas.Item2 == -1)) 
                    return $"Para reservar una silla, el avión debe estar inicializado o la silla {codigo_silla} " +
                        $"no existe en la configuración de este avión";

                if (avion[coordenadas.Item1, coordenadas.Item2].Equals("L"))
                {
                    avion[coordenadas.Item1, coordenadas.Item2] = Obtener_nro_reserva();
                    cantidad_tot_sillas--;
                    return $"La silla {codigo_silla} ha sido reservada exitosamente con el número " +
                        $"de reserva {avion[coordenadas.Item1, coordenadas.Item2]} ";
                }
                else return "La silla está ocupada";
            }
            catch (Exception error)
            {
                throw new Exception($"Se presentó un error al reservar un código de silla, en el avión \n {error.Message}");
            }

        }

        //Método para reservar varias las primeras sillas que encuentre en el avión vacías
        //con el mismo número de reserva

        static string Reservar_silla(byte cant_sillas, string nro_reserva)
        {
            try
            {
                if (avion_inicializado == false || cant_sillas <= cant_max_reser || cant_sillas <= cantidad_tot_sillas) 
                    return $"Para reservar una silla, el avión debe estar inicializado " +
                        $"o la cantidad de sillas a reservar excede el límite de {cant_max_reser} " +
                        $"o la cantidad de sillas que necesita no están disponibiles en el avión";

                string txt_return = "";
                byte cont_asign = 1; 

                for (byte i = 0; i < avion.GetLength(0); i++)
                {
                    for (byte j = 0; j < avion.GetLength(1); j++)
                    {
                        if (avion[i, j].Equals("L") && cont_asign <= cant_sillas)
                        {
                            avion[i, j] = nro_reserva;
                            txt_return += $"Le hemos asignado de forma aleatoria la silla {Convertir_pos_silla(i, j)} con el número " +
                                $"de reserva {nro_reserva} \n";
                            cont_asign++;
                        }
                    }
                }

                return txt_return;

                //Tarea2: Método AnularReserva, que reciba el código de la reserva y pone todas las sillas de la reserva en L

            }
            catch (Exception error)
            {
                throw new Exception($"Se presentó un error al reservar una silla aleatoria en el avión \n {error.Message}");
            }

        }

        //Método para reservar varias sillas en el avión, dando el código de las sillas
        static string Reservar_silla(string[] v_sillas)
        {
            //Tarea3: Hacer este método
            return "";
        }

        static string Imprimir_avion() //Tarea bonus: mostrar las filas y los códigos de silla
        {
            try
            {
                if (avion_inicializado == false) return "Para imprimir el avión, debe estar inicializado";

                String imp_matriz = "";
                const string reset = "\u001b[0m";
                const string rojo = "\u001b[31m";
                const string verde = "\u001b[32m";
                

                for (byte f = 0; f < avion.GetLength(0); f++)
                {

                    for (byte c = 0; c < avion.GetLength(1); c++)
                    {
                        if (avion[f, c].Equals("L")) imp_matriz += verde;
                        else imp_matriz += rojo;
                        imp_matriz += avion[f, c] + "\t";
                        imp_matriz += reset;
                    }
                    imp_matriz += "\n";

                }

                return imp_matriz;
            }
            catch (Exception error)
            {
                throw new Exception($"Error imprimendo la matriz \n {error.Message}");
            }
        }
    }
}
