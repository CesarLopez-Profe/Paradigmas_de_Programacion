﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_multiplexquiz2.Clases
{
    public class Espectador : Persona
    {
        public Espectador(string nombre, long nro_id, long nro_tel) : 
            base(nombre, nro_id, nro_tel)
        {

        }
    }
}
