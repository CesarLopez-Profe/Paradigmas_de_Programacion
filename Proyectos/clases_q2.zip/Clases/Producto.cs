﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_multiplexquiz2.Clases
{
    public class Producto
    {
        private string descripcion;
        private uint valor;

        public Producto(string descripcion, uint valor)
        {
            this.Descripcion = descripcion;
            this.Valor = valor;
        }

        public string Descripcion { get => descripcion; set => descripcion = value; }
        public uint Valor { get => valor; set => valor = value; }
    }
}
