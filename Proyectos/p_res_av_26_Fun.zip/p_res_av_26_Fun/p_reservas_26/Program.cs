﻿using System.Data;
using System.Linq.Expressions;
using System.Security.Cryptography;

namespace p_reservas_26
{
    internal class Program
    {
        //variables globales
        const byte cant_fil = 20, cant_sillxfil = 4, tam_min_cod_sill = 2, cant_max_reser = 5;
        const char letra_inicial = 'A', letra_final = 'Z';
        static Random aleat = new Random();
        const short nro_res_min = 1000, nro_res_max = 9999;
        static bool avion_inicializado = false;
        static byte opc;
        static uint cantidad_tot_sillas = (uint)(cant_fil * cant_sillxfil);

        static string[,] avion = new string[cant_fil, cant_sillxfil];
        static Dictionary<string, string> avion_f;

        
        static void Main(string[] args)
        {
            try
            {
                string codigo_silla;
                string[] v_sillas = { "2A", "2B", "16C", "16D", "16E" };
                byte nro_fila, cant_sillas;

                
                
                do
                {
                    try //bloque try catch para atrapar los errores del menu
                    {
                        Console.WriteLine("""
                                ******MENU********
                                1. Inicializar el Avión
                                2. Reservar una silla aleatoria
                                3. Reservar una silla con código (#Letra)
                                4. Reservar un grupo de sillas aleatorias 
                                5. Reservar un grupo de sillas con códigos 
                                6. Imprimir el estado del avión
                                7. Salir 
                                """);

                        Console.WriteLine("Seleccione su opción: ");


                        if (byte.TryParse(Console.ReadLine(), out opc))
                        {

                            switch (opc)
                            {

                                case 1:
                                    avion_f = Crear_Inicializar_avion();
                                    Console.WriteLine("Se ha creado un avión y se inicializo exitosamente");
                                    break;

                                case 2:
                                    Console.WriteLine(Reservar_silla()); //una silla, la primera que encuentre libre
                                    break;
                                case 3:
                                    Console.WriteLine("Ingrese el codigo de la silla a reservar en formato #fila"); 
                                    codigo_silla = Console.ReadLine();
                                    Console.WriteLine(Reservar_silla(codigo_silla));
                                    break;
                                case 4:
                                    Console.WriteLine("Ingrese la cantidad de sillas que quiere reservar: "); //Tarea1: convertir a tryparse
                                    if (byte.TryParse(Console.ReadLine(), out cant_sillas)) Console.WriteLine(Reservar_silla(cant_sillas, Obtener_nro_reserva()));
                                    else Console.WriteLine($"Valor para la cantidad de sillas no válido");
                                    break;
                                case 5:
                                    Console.WriteLine(Reservar_silla(v_sillas));
                                    break;
                                case 6:
                                    Console.WriteLine(Imprimir_avion());
                                    break;
                                case 7:
                                    Console.WriteLine("Chao");
                                    break;
                                default:
                                    Console.WriteLine("Opción no válida");
                                    break;

                            }
                        }
                    }
                    catch(Exception err)
                    {
                        Console.WriteLine($"Ocurrió un error al ejecutar una opción del menú: \n{err.Message}");
                    }
                }
                while ((opc) != 7);


            }

            catch (Exception e)
            {
                Console.WriteLine($"Ocurrió un error : \n{e.Message}");
            }
        }

        //Métodos Auxiliares
        static string Obtener_nro_reserva()
        {
            try
            {
                int n_reserva = aleat.Next(nro_res_min, nro_res_max);
                return ((char)(aleat.Next(65, 90))).ToString() + "-" + n_reserva;
            }

            catch (Exception e) { throw new Exception($"Ocurrió un error en Obtener_nro_reserva\n{e.Message}"); }

        }

        private static Dictionary<string, string> Crear_Inicializar_avion()
        {
            char[] letras = Enumerable.Range(0, cant_sillxfil)
                         .Select(i => (char)(letra_inicial + i))
                         .ToArray();

            return Enumerable.Range(1, cant_fil*cant_sillxfil)
                .ToDictionary(
                    i => $"{((i - 1) / cant_sillxfil) + 1}{ letras[(i - 1) % cant_sillxfil]}", //El resultado del mod contra el vector de char
                    i => "L"
                );
        }

        //Método para reservar la primera silla libre en el avión
        
        static string Reservar_silla()
        {
            // busca la primera silla libre
            var silla_libre = avion_f.FirstOrDefault(elem => elem.Value == "L");

            var clave = silla_libre.Key == null ? throw new Exception("No hay asientos disponibles"):
                avion_f[silla_libre.Key] = Obtener_nro_reserva();


            return $"La silla {silla_libre.Key} ha sido reservada exitosamente con el número " +
                        $"de reserva {silla_libre.Value} ";
        }

        //Método para reservar una silla en el avión con el código que quiere el pasajero 
        static string Reservar_silla(string codigo_silla)
        {
            var res = avion_f.ContainsKey(codigo_silla) ? avion_f[codigo_silla] = Obtener_nro_reserva():
                throw new Exception("No hay asientos disponibles");

                
            return $"La silla {codigo_silla} ha sido reservada exitosamente con el código de reserva: {avion_f[codigo_silla]}";
        }

        //Método para reservar varias las primeras sillas que encuentre en el avión vacías
        //con el mismo número de reserva

        static string Reservar_silla(byte cant_sillas, string nro_reserva)
        {
            // 1. CONTAR cuántos elementos con "L" existen
            int sillas_libres = avion_f.Count(silla => silla.Value == "L");

            // Verificar si hay suficientes
            if (sillas_libres <= cant_sillas)
                return ($"No hay suficientes asientos libres. Necesarios: {cant_sillas}, Disponibles: {sillas_libres}");

            string txt_return = "";

            // 2. OBTENER los primeros N elementos con "L"
            var list_sillas_lib = avion_f
                .Where(kvp => kvp.Value == "L")
                .Take(cant_sillas)
                .ToList();

            // 3. CAMBIAR el valor de esos elementos
            foreach (var silla in list_sillas_lib)
            {
                avion_f[silla.Key] = nro_reserva;
                txt_return+=($"Asiento {silla.Key} reservado con código {nro_reserva}\n");
            }

            return txt_return;
        }

        //Método para reservar varias sillas en el avión, dando el código de las sillas
        static string Reservar_silla(string[] v_sillas)
        {
            //Tarea1: Hacer este método funcional
            return "";
        }

        static string Imprimir_avion()
        {
            //tarea 2: imprimir funcional por filas
            const string reset = "\u001b[0m";
            const string rojo = "\u001b[31m";
            const string verde = "\u001b[32m";

            return string.Join("\n",
                avion_f.Select(silla =>
                $"{(silla.Value == "L" ? verde : rojo)}" + 
                $"{silla.Key}: {silla.Value}" +
                reset));

        }
    }
}
