﻿using p_parque.Clases;
using System.Reflection.Metadata.Ecma335;

namespace p_parque
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                List<Atraccion> atracc = new List<Atraccion>();
                atracc.Add(new Atraccion("Montaña Rusa", 25));
                atracc.Add(new Atraccion("Montaña de Agua", 18));
                atracc.Add(new Atraccion("Torre", 20));
                atracc.Add(new Atraccion("Carrusel", 10));
                atracc.Add(new Atraccion("Barco Vikingo", 20));
                atracc.Add(new Atraccion("Kamikazee", 30));
                atracc.Add(new Atraccion("Carros Chocones Adultos", 25));
                atracc.Add(new Atraccion("Carros Chocones Niños", 22));
                atracc.Add(new Atraccion("Tiro al blanco", 12));
                atracc.Add(new Atraccion("Rueda de Chicago", 16));

                Parque parque_sur = new Parque("Parque Sur", atracc);
                Console.WriteLine(parque_sur.ToString());
                Console.WriteLine(ImprimirTaquillas(parque_sur));

                parque_sur.Abrir();
                Console.WriteLine(parque_sur.ToString());
                Console.WriteLine(ImprimirTaquillas(parque_sur));

                Manilla manilla_juan, manilla_pepe, manilla_sara;

                manilla_juan = parque_sur.L_taquillas.ElementAt(0).VenderManilla(50000);
                manilla_pepe = parque_sur.L_taquillas.ElementAt(1).VenderManilla(100000);
                manilla_sara = parque_sur.L_taquillas.ElementAt(2).VenderManilla(250000);

                Console.WriteLine(manilla_pepe.ToString());
                Console.WriteLine(manilla_juan.ToString());
                Console.WriteLine(manilla_sara.ToString());

                Console.WriteLine(ImprimirTaquillas(parque_sur));

                parque_sur.L_registros.Add(parque_sur.L_atracciones.ElementAt(6).RegistrarIngreso(manilla_juan));
                parque_sur.L_registros.Add(parque_sur.L_atracciones.ElementAt(5).RegistrarIngreso(manilla_pepe));
                parque_sur.L_registros.Add(parque_sur.L_atracciones.ElementAt(8).RegistrarIngreso(manilla_juan));
                parque_sur.L_registros.Add(parque_sur.L_atracciones.ElementAt(1).RegistrarIngreso(manilla_sara));

                Console.WriteLine(manilla_juan.ToString());

                Console.WriteLine(ImprimirRegistros(parque_sur));






            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message.ToString());
            }

            finally
            {
                Console.WriteLine("Termina ejecución");
                Console.ReadKey();
            }
        }

        public static string ImprimirTaquillas(Parque parque)
        {
            string txt_retornar = "";

            foreach(Taquilla t in parque.L_taquillas)
            {
                txt_retornar += t.ToString()+"\n";
            }
            return txt_retornar;
        }

        public static string ImprimirRegistros(Parque parque)
        {
            string txt_retornar = "";

            foreach (Registro r in parque.L_registros)
            {
                txt_retornar += r.ToString() + "\n";
            }
            return txt_retornar;
        }

    }
}
