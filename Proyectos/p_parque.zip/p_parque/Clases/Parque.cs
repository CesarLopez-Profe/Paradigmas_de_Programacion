﻿using p_parque.Clases.Reglas;
using System;
using System.Collections.Generic;
using System.Text;

namespace p_parque.Clases
{
    internal class Parque
    {
        private string nombre;
        private List<Atraccion> l_atracciones;
        private List<Taquilla> l_taquillas;
        private List<Registro> l_registros;
        private List<Manilla> l_manillas;
        private bool abierto;

        public Parque(string nombre, List<Atraccion> l_atracciones)
        {
            l_registros = new List<Registro>();
            l_manillas = new List<Manilla>(ReglasParque.max_manillas_parque);
            l_taquillas = new List<Taquilla>(ReglasParque.id_max_taquilla);
            this.l_atracciones = new List<Atraccion>();
            this.Nombre = nombre;
            this.L_atracciones = l_atracciones;
            Crear_taquillas();
            Crear_manillas();
            abierto = false;
        }

        public string Nombre { get => nombre; 
            set => nombre = value.Length>=ReglasParque.long_min_nom?value:
                throw new Exception($"La longitud del nombre debe ser mayor a {ReglasParque.long_min_nom}"); }
        internal List<Atraccion> L_atracciones { get => l_atracciones; 
            set => l_atracciones = value.Count() == ReglasParque.cant_atracc?value:
                throw new Exception($"Las atracciones deben ser {ReglasParque.cant_atracc}");
        }
        internal List<Taquilla> L_taquillas { get => l_taquillas;  }
        internal List<Manilla> L_manillas { get => l_manillas;  }
        internal List<Registro> L_registros { get => l_registros; 
            set => l_registros = value; }

        private void Crear_taquillas()
        {
            try
            {
                for(byte taq = ReglasParque.id_min_taquilla; taq <=ReglasParque.id_max_taquilla; taq++)
                {
                    l_taquillas.Add(new Taquilla(taq));
                }
            }
            catch (Exception err)
            {
                throw new Exception($"Error creando taquillas en parque {err.Message.ToString()}");
            }
        }

        private void Crear_manillas()
        {
            try
            {
                for (uint man = ReglasParque.min_manillas; man < ReglasParque.max_manillas_parque; man++)
                {
                    l_manillas.Add(new Manilla());
                }
            }
            catch (Exception err)
            {
                throw new Exception($"Error creando manillas en parque {err.Message.ToString()}");
            }
        }

        internal bool Entregar_Manillas(Taquilla taquilla)
        {
            try
            {
                if (!abierto) throw new Exception("No se pueden enviar manillas con el parque cerrado");
                else if (!l_taquillas.Contains(taquilla)) throw new Exception($"No se pueden enviar manillas a la taquilla {taquilla.Id}");
                else if (!taquilla.Abierta) throw new Exception($"La taquilla {taquilla.Id} está cerrada, no se puede enviar manillas");
                else if (l_manillas.Count < ReglasParque.max_manillas_taquilla) throw new Exception("El parque no tiene suficientes manillas para entregarle a las taquilla");
                else if (taquilla.L_manillas_disp.Count > ReglasParque.min_manillas ) throw new Exception("La taquilla aún tiene manillas, no se puede enviar");
                else
                {
                    taquilla.L_manillas_disp = l_manillas.Take(ReglasParque.max_manillas_taquilla).ToList();
                    l_manillas.RemoveRange(0,ReglasParque.max_manillas_taquilla);
                    return true;
                 }
            }
            catch (Exception err)
            {
                throw new Exception($"Error entregando manillas en parque {err.Message.ToString()}");
            }

        }

        internal void Abrir()
        {
            try
            {
                abierto = true;
                foreach(Taquilla t in l_taquillas)
                {
                    t.Abrir();
                    Entregar_Manillas(t);
                }
            }
            catch (Exception err)
            {
                throw new Exception($"Error abriendo parque {err.Message.ToString()}");
            }
        }

        internal void Cerrar()
        {
            try
            {
                foreach (Taquilla t in l_taquillas) { t.Cerrar(); }
                abierto = false;
            }
            catch (Exception err)
            {
                throw new Exception($"Error cerrando parque {err.Message.ToString()}");
            }
        }

        public override string ToString()
        {
            string atracciones = string.Join(Environment.NewLine, l_atracciones.Select(t => $"{t.Nombre}"));

            return $"{nombre.ToUpper()}\n"+
                $"\n****************\nATRACCIONES\n****************\n{atracciones}\n"+
                $"Manillas Disponibles {l_manillas.Count.ToString("n")}\n" +
                $"{(abierto ? $"{Color.verde}Abierto\n" : $"{Color.rojo}Cerrado\n")}" +
                $"{Color.reset}";
        }

    }
}
