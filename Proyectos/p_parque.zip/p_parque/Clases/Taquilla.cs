﻿using p_parque.Clases.Reglas;
using System;
using System.Collections.Generic;
using System.Text;

namespace p_parque.Clases
{
    internal class Taquilla
    {
        private byte id;
        private List<Manilla> l_manillas_disp;
        private List<Manilla> l_manillas_vend;
        private ulong saldo_dinero;
        private bool abierta;

        public Taquilla(byte id)
        {
            this.Id = id;
            l_manillas_disp = new List<Manilla>();
            l_manillas_vend = new List<Manilla>();
            saldo_dinero = ReglasParque.saldo_inicial_taq;
            abierta = false;
        }

        public byte Id { get => id; 
            set => id = value>=ReglasParque.id_min_taquilla && value <=ReglasParque.id_max_taquilla?
                value:throw new Exception($"El id de la taquilla debe ir entre {ReglasParque.id_min_taquilla} y " +
                    $"{ReglasParque.id_max_taquilla}"); }
        public ulong Saldo_dinero { get => saldo_dinero;  }
        public bool Abierta { get => abierta;  }
        internal List<Manilla> L_manillas_disp { get => l_manillas_disp;
            set => l_manillas_disp = value.Count == ReglasParque.max_manillas_taquilla ?
                value : throw new Exception($"La taquilla solo recibe lotes de {ReglasParque.max_manillas_taquilla} manillas"); }
        internal List<Manilla> L_manillas_vend { get => l_manillas_vend; }

        public void Abrir() { if(!abierta) abierta = true;  }
        public void Cerrar() { if (abierta) abierta = false; }
        public ushort ObtenerManillasVendidas() { return (ushort)l_manillas_vend.Count(); }

        public Manilla VenderManilla(uint monto)
        {
            try
            {
                
                if (!abierta) { throw new Exception("La taquilla está cerrada");}
                
                if (monto < ReglasParque.monto_min_carga)
                    { throw new Exception($"El monto mínimo de carga es: {ReglasParque.monto_min_carga}"); }

                if (l_manillas_disp.Count() == 0) { throw new Exception("No hay manillas para vender"); }

                Manilla manilla_return = new Manilla();
                manilla_return = l_manillas_disp.ElementAt(0);
                manilla_return.Sdo_puntos = (monto - ReglasParque.valor_entrada) / ReglasParque.valor_pto;
                l_manillas_vend.Add(manilla_return);
                l_manillas_disp.RemoveAt(0);
                return manilla_return;

            }
            catch (Exception ex)
            { throw new Exception($"Ocurrió un error en VenderManilla {ex.Message.ToString()}"); }
        }

        public override string ToString()
        {
            return $"Informació Taquilla {id}\n" +
                $"Cantidad de manillas disponibles {l_manillas_disp.Count}\n" +
                $"Cantidad de manillas vendidas {l_manillas_vend.Count}\n" +
                $"Saldo de Dinero {saldo_dinero.ToString("c")}\n" +
                $"{(abierta ? $"{Color.verde}Abierta" : $"{Color.rojo}Cerrada")}" +
                $"{Color.reset}";
             


        }

    }
}
