﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_parque.Clases
{
    internal class Registro
    {
        private Manilla manilla;
        private Atraccion atraccion;
        private DateTime fecha_hora;

        public Registro(Manilla manilla, Atraccion atraccion)
        {
            this.manilla = manilla;
            this.atraccion = atraccion;
            fecha_hora = DateTime.Now;
        }

        public override string ToString()
        {
            return $"Registro de la manilla {manilla.Id}\n" +
                $"ingresó a la atraccion {atraccion.Nombre}\n" +
                $"en la fecha y hora {fecha_hora}";

        }
    }
}
