﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_parque.Clases.Reglas
{
    internal static class Color
    {
        public static readonly string rojo = "\u001b[31m";
        public static readonly string verde = "\u001b[32m";
        public static readonly string reset = "\u001b[0m";
    }
}
