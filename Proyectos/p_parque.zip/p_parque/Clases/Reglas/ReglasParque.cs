﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_parque.Clases.Reglas
{
    internal static class ReglasParque
    {
        internal static readonly byte long_min_nom = 5;
        internal static readonly byte ptos_min_ing_atr = 10;
        internal static readonly byte ptos_max_ing_atr = 30;
        internal static readonly byte id_min_taquilla = 1;
        internal static readonly byte id_max_taquilla = 3;
        internal static readonly byte min_manillas = 0;
        internal static readonly byte max_manillas_taquilla = 100;
        internal static readonly ushort max_manillas_parque = 1000;
        internal static readonly byte cant_atracc = 10;
        internal static readonly byte saldo_inicial_taq = 0;
        internal static readonly uint monto_min_carga = 20000;
        internal static readonly uint valor_entrada = 4000;
        internal static readonly uint valor_pto = 500;

    }
}
