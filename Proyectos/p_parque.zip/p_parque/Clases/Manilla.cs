﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace p_parque.Clases
{
    internal class Manilla
    {
        private ulong id;
        private uint sdo_puntos;

        public Manilla()
        {
            Random a = new Random();
            id = (ulong)a.NextInt64(1000000, 10000000);
            Sdo_puntos = 0;
        }

        public ulong Id { get => id; }

        public uint Sdo_puntos
        {
            get => sdo_puntos;
            set => sdo_puntos = value >= 0 ?
                value : throw new Exception("El saldo de la manilla no puede estar debajo de cero");
        }


        public override string ToString()
        {
            return $"Id: {id} - Puntos Disponibles: {sdo_puntos}\n";
        }

    }
}