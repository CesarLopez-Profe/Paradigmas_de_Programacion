﻿using p_parque.Clases.Reglas;
using System;
using System.Collections.Generic;
using System.Text;

namespace p_parque.Clases
{
    internal class Atraccion
    {
        private string nombre;
        private byte ptos_ingresar;

        public Atraccion(string nombre, byte ptos_ingresar)
        {
            this.Nombre = nombre;
            this.Ptos_ingresar = ptos_ingresar;
        }

        public string Nombre { get => nombre;
            set => nombre = value.Length >= ReglasParque.long_min_nom ? value :
                throw new Exception($"La longitud mínima del nombre de la atracción debe ser {ReglasParque.long_min_nom}");
        }

        public byte Ptos_ingresar { get => ptos_ingresar; 
            set => ptos_ingresar = value >= ReglasParque.ptos_min_ing_atr && value <= ReglasParque.ptos_max_ing_atr?
                value:
                throw new Exception($"Los puntos deben ser entre {ReglasParque.ptos_min_ing_atr} y {ReglasParque.ptos_max_ing_atr}");
        }

        public Registro RegistrarIngreso(Manilla manilla)
        {
            try
            {
                bool ingreso_exitoso = false;
                if (manilla.Sdo_puntos >= ptos_ingresar)
                {
                    //manilla.Sdo_ptos = (ushort)(manilla.Sdo_ptos - ptos_ingresar);
                    manilla.Sdo_puntos -= ptos_ingresar;
                    return new Registro(manilla, this);
                }
                else throw new Exception($"Se necesitan {ptos_ingresar} puntos para ingresar a {nombre} ");
            }
            catch (Exception e)
            {
                throw new Exception($"Error no esperado en Registrar Ingreso\n{e.Message.ToString()} ");
            }
        }

        public override string ToString()
        {
            return $"Información de la Atracción\n" +
                $"Nombre: {nombre}\nPuntos para ingresar: {ptos_ingresar}\n";
        }
    }
}
