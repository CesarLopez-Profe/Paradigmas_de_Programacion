﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_concesionario.Reglas
{
    internal abstract class ReglaNegocio
    {
        internal static readonly float descto_min = 0.01f;
        internal static readonly float descto_max = 0.025f;
        internal static readonly float com_min = 0.015f;
        internal static readonly float com_max = 0.02f;
        internal static readonly ulong val_min_auto = 80000000;
    }
}
