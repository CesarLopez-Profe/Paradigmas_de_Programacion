﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_concesionario.Clases
{
    internal abstract class Automovil
    {
        private string placa;
        private string marca;
        private string modelo;
        private ushort ano;
        private ushort cilindraje;
        private RglsConc.cant_puestos cant_puestos;
        private RglsConc.cant_puertas cant_puertas;
        private uint kilometraje;

        protected Automovil(string placa, string marca, string modelo, ushort ano, ushort cilindraje, 
            RglsConc.cant_puestos cant_puestos, RglsConc.cant_puertas cant_puertas)
        {
            this.Placa = placa;
            this.Marca = marca;
            this.Modelo = modelo;
            this.Ano = ano;
            this.Cilindraje = cilindraje;
            this.cant_puestos = cant_puestos;
            this.cant_puertas = cant_puertas;
            kilometraje = RglsConc.km_inicial;
        }

        public string Placa { get => placa; 
            set => placa = System.Text.RegularExpressions.Regex.IsMatch(value.ToString(), RglsConc.xr_placa) ? value
                : throw new Exception("La placa no es válida"); }
        public string Marca { get => marca; 
            set => marca = value.Length >= RglsConc.long_min_marca &&
                !string.IsNullOrWhiteSpace(value) && !string.IsNullOrEmpty(value) ?
                value : throw new Exception("El nombre no es válido"); }
        public string Modelo { get => modelo; set => modelo = value.Length >= RglsConc.long_min_modelo &&
                !string.IsNullOrWhiteSpace(value) && !string.IsNullOrEmpty(value) ?
                value : throw new Exception("El nombre no es válido"); }
        public ushort Ano { get => ano; set => ano = value >= DateTime.Now.Year && 
                value <= DateTime.Now.Year + RglsConc.vig_ano ? value
                : throw new Exception("El año no es váldo"); }
        public ushort Cilindraje { get => cilindraje; 
            set => cilindraje = value >=RglsConc.cil_min && value <=RglsConc.cil_max?value:
                throw new Exception("El cilindraje no es válido"); }
    }
}
