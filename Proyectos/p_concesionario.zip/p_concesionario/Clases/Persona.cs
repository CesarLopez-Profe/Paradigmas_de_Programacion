﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_concesionario.Clases
{
    internal abstract class Persona
    {
        private ulong cedula;
        private string nombre;

        protected Persona(ulong cedula, string nombre)
        {
            this.Cedula = cedula;
            this.Nombre = nombre;
        }

        public ulong Cedula { get => cedula; 
            set => cedula = value > 0 ? value:throw new Exception("La cedula debe ser mayor a cero\n"); }
        public string Nombre { get => nombre; 
            set => nombre = value.Length >= 10 && !string.IsNullOrEmpty(value) && !string.IsNullOrWhiteSpace(value) ? value:
                throw new Exception("El nombre no puede contener espacios en blanco, no debe ser nulo y debe ser mayor a 10 caracteres\n"); }
    }
}
