﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_concesionario.Clases
{
    internal abstract class Persona
    {
        private ulong cedula;
        private string nombre;

        protected Persona(ulong cedula, string nombre)
        {
            this.Cedula = cedula;
            this.Nombre = nombre;
        }

        public ulong Cedula { get => cedula;
            set => cedula = System.Text.RegularExpressions.Regex.IsMatch(value.ToString(), RglsConc.xr_cedula) ?
                value : throw new Exception("La cédula no es válida")
                ; }
        public string Nombre { get => nombre;
            set => nombre = value.Length >= RglsConc.long_min_nombre && 
                !string.IsNullOrWhiteSpace(value) && !string.IsNullOrEmpty(value) ?
                value:throw new Exception("El nombre no es válido"); }


        

    }
}
