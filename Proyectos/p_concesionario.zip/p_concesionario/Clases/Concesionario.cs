﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_concesionario.Clases
{
    internal class Concesionario
    {
        private string nombre;
        private string direccion;
        private List<Venta> l_ventas;

        public Concesionario(string nombre, string direccion)
        {
            this.Nombre = nombre;
            this.Direccion = direccion;
            l_ventas = new List<Venta>();
        }

        public string Nombre { get => nombre; set => 
                nombre = value.Length >= RglsConc.long_min_nombre?value:
                throw new Exception("La longitud para el nombre del concesionario no es válida"); }
        public string Direccion { get => direccion; set => direccion = value.Length >= RglsConc.long_min_dir ? value :
                throw new Exception("La longitud para la dirección del concesionario no es válida");
        }
        internal List<Venta> L_ventas { get => l_ventas;  }

        public bool Vender_auto((Persona vendedor, Persona cliente) l_personas, Automovil auto, ulong valor)
        {
            l_ventas.Add(new Venta(l_personas, auto, valor));            
            return true;
        }

    }
}
