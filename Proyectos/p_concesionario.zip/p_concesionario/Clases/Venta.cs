﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_concesionario.Clases
{
    internal class Venta
    {
        // Atributo tipo tupla
        private (Persona vendedor, Persona cliente) l_personas;
        private Automovil automovil;
        private DateTime fecha;
        private ulong valor;

        public Venta((Persona vendedor, Persona cliente) l_personas, Automovil automovil, ulong valor)
        {
            this.L_personas = l_personas;
            this.automovil = automovil;
            fecha = DateTime.Now;
            this.Valor = valor;
        }

        internal ulong Valor { get => valor; set => valor = value>=RglsConc.val_min_auto?value:
                throw new Exception("El valor del auto no es válido"); }
        internal (Persona vendedor, Persona cliente) L_personas { get => l_personas; 
            set => l_personas = value.vendedor is Vendedor && value.cliente is Cliente?value:
                throw new Exception("Las personas reportadas en la venta no son válidas"); }
        internal Automovil Automovil { get => automovil;  }
    }
}
