﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_concesionario.Clases
{
    internal class Deportivo:Automovil
    {
        private bool coupe;
        private bool descapotable;

        public Deportivo(string placa, string marca, string modelo, ushort ano, ushort cilindraje, 
            RglsConc.cant_puestos cant_puestos, RglsConc.cant_puertas cant_puertas, bool coupe, bool descapotable) : 
            base(placa, marca, modelo, ano, cilindraje, cant_puestos, cant_puertas)
        {
            this.coupe = coupe;
            this.descapotable = descapotable;
        }

        public bool Coupe { get => coupe; }
        public bool Descapotable { get => descapotable;  }
    }
}
