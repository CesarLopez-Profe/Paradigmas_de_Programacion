﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_concesionario.Clases
{
    internal class Taxi : Automovil
    {
        private string nro_tarjeta;
        private string empresa;

        public Taxi(string placa, string marca, string modelo, ushort ano, ushort cilindraje,
            RglsConc.cant_puestos cant_puestos, RglsConc.cant_puertas cant_puertas, string nro_tarjeta,string empresa) : 
            base(placa, marca, modelo, ano, cilindraje, cant_puestos, cant_puertas)
        {
            Nro_tarjeta = nro_tarjeta;
            Empresa = empresa;
        }

        public string Nro_tarjeta { get => nro_tarjeta;           
            set => nro_tarjeta = value.Length >= RglsConc.long_top && !string.IsNullOrEmpty(value) 
                && !string.IsNullOrWhiteSpace(value)? value : throw new Exception("La tarjeta de operación no es válida");
        }
        public string Empresa { get => empresa; set => empresa = value.Length >= RglsConc.emp_taxi && !string.IsNullOrEmpty(value)
                && !string.IsNullOrWhiteSpace(value)? value : throw new Exception("la empresa suministrada no es válida");
    }
    }
}
