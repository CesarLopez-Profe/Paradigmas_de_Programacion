﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_concesionario.Clases
{
    internal static class RglsConc
    {
        public enum cant_puertas {p2,p3,p4, p5};
        public enum cant_puestos {p2,p5,p7};


        public static readonly float desc_min = 0.01f;
        public static readonly float desc_max = 0.025f;
        public static readonly float comis_min = 0.015f;
        public static readonly float comis_max = 0.02f;
        public static readonly ulong val_min_auto = 80000000;
        public static readonly byte km_inicial = 0;
        public static readonly byte long_min_nombre = 10;
        public static readonly byte long_min_dir = 10;
        public static readonly byte long_min_marca = 3;
        public static readonly byte long_min_modelo = 1;
        public static readonly byte vig_ano = 2;
        public static readonly byte long_top = 5;
        public static readonly byte emp_taxi = 6;
        public static readonly byte cant_min_exp = 1;
        public static readonly byte cant_max_exp = 6;
        public static readonly ushort cil_min = 1000;
        public static readonly ushort cil_max = 6000;




        //Expresiones regulares
        public static readonly string xr_cedula = @"^\d{1,10}$";
        public static readonly string xr_placa = @"^[A-Z]{3}\d{3}$";
    }
}
