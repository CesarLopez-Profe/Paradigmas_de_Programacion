﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_concesionario.Clases
{
    internal class Cliente : Persona
    {
        private float val_descto;
        public Cliente(ulong cedula, string nombre, float val_descto) 
            : base(cedula, nombre)
        {
            Val_descto = val_descto;
        }

        public float Val_descto { get => val_descto; 
            set => val_descto = value >=RglsConc.desc_min && value <=RglsConc.desc_max ? value 
                : throw new Exception("El descuento otorgado no es válido"); }
    }
}
