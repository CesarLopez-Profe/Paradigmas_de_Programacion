﻿using p_concesionario.Reglas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_concesionario.Clases
{
    internal class Cliente:Persona 
    {
        private float val_descto;

        public Cliente(ulong cedula, string nombre, float val_descto) 
            : base(cedula, nombre)
        {
            Val_descto = val_descto;
        }

        public float Val_descto { get => val_descto; 
            set => val_descto = value>=ReglaNegocio.descto_min && value<=ReglaNegocio.descto_max?value:throw new Exception($"El valor del descuento no es válido {value}") ; }
    }
}
