﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_concesionario.Clases
{
    internal class Vendedor:Persona
    {
        private float comision;

        public Vendedor(ulong cedula, string nombre, float comision) 
            : base(cedula, nombre)
        {
            Comision = comision;
        }

        public float Comision { get => comision; 
            set => comision = value >=RglsConc.comis_min && value <=RglsConc.comis_max?value:
                throw new Exception("La comisión para el vendedor no es válida"); }
    }
}
