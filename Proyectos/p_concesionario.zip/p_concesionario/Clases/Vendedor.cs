﻿using p_concesionario.Reglas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p_concesionario.Clases
{
    internal class Vendedor:Persona
    {
        private float val_comision;

        public Vendedor(ulong cedula, string nombre, float val_comision) 
            : base(cedula, nombre)
        {
            Val_comision = val_comision;
        }

        public float Val_comision { get => val_comision; set => val_comision = value >= ReglaNegocio.com_min && value <= ReglaNegocio.com_max ? value : throw new Exception($"El valor de la comisión no es válida {value}"); }
    }
}
