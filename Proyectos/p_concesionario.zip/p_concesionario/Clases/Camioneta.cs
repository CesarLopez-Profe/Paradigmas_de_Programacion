﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_concesionario.Clases
{
    internal class Camioneta:Automovil
    {
        private bool doble = false;
        private byte nro_explo;

        public Camioneta(string placa, string marca, string modelo, ushort ano, ushort cilindraje,
            RglsConc.cant_puestos cant_puestos, RglsConc.cant_puertas cant_puertas, bool doble, byte nro_explo) :
            base(placa, marca, modelo, ano, cilindraje, cant_puestos, cant_puertas)
        {
            this.doble = doble;
            Nro_explo = nro_explo;
            
        }

        public byte Nro_explo { get => nro_explo;
            set => nro_explo = value >= RglsConc.cant_min_exp && value <= RglsConc.cant_max_exp ? value :
                throw new Exception("El número de exploradoras no es válido"); }
        public bool Doble { get => doble;  }
    }
}
