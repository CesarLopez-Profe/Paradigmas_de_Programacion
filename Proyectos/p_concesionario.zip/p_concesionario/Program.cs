﻿using p_concesionario.Clases;

namespace p_concesionario
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {

                Cliente Susana_123 = new Cliente(235845664, "Susana gómez", 0.018f);
                Vendedor Juan_123 = new Vendedor(89132123, "Juan Perez", 0.015f);

                if (Susana_123 is Persona)
                {
                    Console.WriteLine("Susana es persona");
                    if (Susana_123 is Cliente)
                        Console.WriteLine("Susana es Cliente ");
                    else if (Susana_123 is Vendedor)
                        Console.WriteLine("Susana es Vendedora");
                }
                else
                    Console.WriteLine("Susana no es Persona");


            }
            catch (Exception ex) { 
                Console.WriteLine(ex.ToString());
            }

           

        }
    }
}
