﻿using p_concesionario.Clases;

namespace p_concesionario
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Taxi tax01 = new Taxi("AAA123", "Chevrolet", "Citi taxi", 2026, 1000, 
                    RglsConc.cant_puestos.p5, RglsConc.cant_puertas.p5, "TO0011", "Tax Individual");

                Camioneta cam01 = new Camioneta("BBB002", "Ford", "Ranger", 2027, 4000, 
                    RglsConc.cant_puestos.p5, RglsConc.cant_puertas.p4, true, 4);

                Vendedor juan = new Vendedor(76598001, "Juan Miguel Carmona", 0.019f);
                Cliente maria = new Cliente(43687999, "Maria Arias", 0.02f);

                Concesionario auto_honrado = new Concesionario("Auto Honrado", "Calle 100 # 20-20");

                auto_honrado.Vender_auto((juan, maria), cam01, 190000000);
                auto_honrado.Vender_auto((juan, maria), tax01, 160000000);


                foreach (Venta v in auto_honrado.L_ventas)
                {
                    Console.WriteLine(v.Valor.ToString("c"));
                }



            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }

            finally {

                Console.WriteLine("Fin de ejecución");
                Console.ReadKey();
                
            }

        }
    }
}
